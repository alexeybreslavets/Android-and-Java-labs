import javax.swing.*;
import java.awt.*;

public class zapusk {
    public static void main(String args[]){
        okno mainFrame = new okno();
        mainFrame.setSize(450, 200);
        mainFrame.setTitle("Работа №4");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setVisible(true);
    }
}