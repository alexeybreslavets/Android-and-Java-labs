public class vagon2 extends vagon {
	private int[] Mesta;

	public void IzmenitxChisloMest(int NovoeChisloMest){
		super.ChisloMest = NovoeChisloMest;
	}
	
	public void PustojVagon(int NomerVagona) {
		NomerEtogoVagona = NomerVagona;
		Mesta = new int[ChisloMest];
		for (int i = 0; i < ChisloMest; i++)
			Mesta[i] = 0;// 0 - признак того, что место свободно
	}
	
	public void ZanyatxMesto(int NomerMesta) {
		switch(Mesta[NomerMesta - 1]){
			case 1: System.out.println("\nThis seats by number " + NomerMesta + " at " + NomerEtogoVagona + " carriage is already is busy!"); break;
			case 0: Mesta[NomerMesta-1] = 1; break;
			default: System.out.println("Error!"); break;
		}
	}
	
	public void VagonInfo() {
		System.out.println("Number of this carriage is " + NomerEtogoVagona);
		int ChisloSvobodMest = 0;
		for (int i = 0; i < ChisloMest; i++)
			if (Mesta[i] == 0)
				ChisloSvobodMest++;
		System.out.println("Quantity of free seats is " + ChisloSvobodMest);
		System.out.println("Information about free seats:");
		for (int i = 0; i < ChisloMest; i++)
			if (Mesta[i] == 0)
				System.out.print((i + 1) + " ");
		System.out.println("");
	}
}